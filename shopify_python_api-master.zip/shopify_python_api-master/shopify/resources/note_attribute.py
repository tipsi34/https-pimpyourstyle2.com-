from ..base import ShopifyResource


class NoteAttribute(ShopifyResource):
    pass

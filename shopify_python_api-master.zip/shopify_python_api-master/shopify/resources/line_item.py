from ..base import ShopifyResource


class LineItem(ShopifyResource):
    class Property(ShopifyResource):
        pass

from .customer_saved_search import CustomerSavedSearch


class CustomerGroup(CustomerSavedSearch):
    pass

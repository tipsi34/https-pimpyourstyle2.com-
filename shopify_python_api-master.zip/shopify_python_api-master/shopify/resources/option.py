from ..base import ShopifyResource


class Option(ShopifyResource):
    pass

from ..base import ShopifyResource


class Currency(ShopifyResource):
    pass

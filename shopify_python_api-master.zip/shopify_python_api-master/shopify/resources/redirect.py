from ..base import ShopifyResource


class Redirect(ShopifyResource):
    pass

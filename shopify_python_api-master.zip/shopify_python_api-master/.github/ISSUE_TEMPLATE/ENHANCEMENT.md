---
name: '📈 Enhancement'
about: Enhancement to our codebase that isn't a adding or changing a feature
labels: "Type: Enhancement 📈"
---

## Overview/summary

...

## Motivation

> What inspired this enhancement?

...

### Area

- [ ] Add any relevant `Area: <area>` labels to this issue


---

## Checklist

- [ ] I have described this enhancement in a way that is actionable (if possible)

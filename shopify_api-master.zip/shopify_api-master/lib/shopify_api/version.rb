# frozen_string_literal: true
module ShopifyAPI
  VERSION = "9.4.1"
end

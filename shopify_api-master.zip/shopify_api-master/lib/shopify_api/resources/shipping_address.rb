# frozen_string_literal: true
module ShopifyAPI
  class ShippingAddress < Base
  end
end

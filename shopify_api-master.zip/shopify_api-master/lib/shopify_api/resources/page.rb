# frozen_string_literal: true
module ShopifyAPI
  class Page < Base
    include Events
    include Metafields
  end
end

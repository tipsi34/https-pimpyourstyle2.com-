# frozen_string_literal: true
module ShopifyAPI
  class Publication < Base
  end
end

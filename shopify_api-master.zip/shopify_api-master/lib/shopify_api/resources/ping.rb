# frozen_string_literal: true

Dir.glob("#{File.dirname(__FILE__)}/ping/*").each { |file| require file }

# frozen_string_literal: true
module ShopifyAPI
  class DraftOrderInvoice < Base
  end
end

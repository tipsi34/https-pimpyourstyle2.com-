# frozen_string_literal: true
module ShopifyAPI
  class TaxService < Base
  end
end

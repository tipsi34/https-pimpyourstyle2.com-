# frozen_string_literal: true
module ShopifyAPI
  class UsageCharge < Base
    init_prefix :recurring_application_charge
  end
end

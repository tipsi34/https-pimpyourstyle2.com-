# frozen_string_literal: true
module ShopifyAPI
  class User < Base
  end
end

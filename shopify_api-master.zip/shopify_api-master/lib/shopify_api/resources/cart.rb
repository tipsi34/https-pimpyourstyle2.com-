# frozen_string_literal: true
module ShopifyAPI
  class Cart < Base
  end
end

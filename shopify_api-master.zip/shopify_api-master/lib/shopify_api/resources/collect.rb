# frozen_string_literal: true
module ShopifyAPI
  # For adding/removing products from custom collections
  class Collect < Base
    early_july_pagination_release!
  end
end

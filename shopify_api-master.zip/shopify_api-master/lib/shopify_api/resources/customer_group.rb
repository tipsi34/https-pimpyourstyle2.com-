# frozen_string_literal: true
require 'shopify_api/resources/customer_saved_search'

module ShopifyAPI
  CustomerGroup = CustomerSavedSearch
end

# frozen_string_literal: true

module ShopifyAPI
  class AbandonedCheckout < Base
    self.element_name = "checkout"
  end
end

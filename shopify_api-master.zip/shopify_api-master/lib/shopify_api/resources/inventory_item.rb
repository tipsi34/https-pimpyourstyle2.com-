# frozen_string_literal: true

module ShopifyAPI
  class InventoryItem < Base
  end
end

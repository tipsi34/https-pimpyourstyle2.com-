# frozen_string_literal: true

module ShopifyAPI
  class TenderTransaction < Base
  end
end

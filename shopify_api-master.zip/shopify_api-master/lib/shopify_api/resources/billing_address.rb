# frozen_string_literal: true
module ShopifyAPI
  class BillingAddress < Base
  end
end

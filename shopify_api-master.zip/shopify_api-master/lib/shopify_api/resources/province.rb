# frozen_string_literal: true
module ShopifyAPI
  class Province < Base
    init_prefix :country
  end
end

# frozen_string_literal: true
module ShopifyAPI
  class ShippingZone < Base
  end
end

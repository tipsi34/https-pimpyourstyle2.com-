# frozen_string_literal: true
module ShopifyAPI
  class Receipt < Base
  end
end

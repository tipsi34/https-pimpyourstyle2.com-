# frozen_string_literal: true
module ShopifyAPI
  class Transaction < Base
    init_prefix :order
  end
end

# frozen_string_literal: true
module ShopifyAPI
  class Report < Base
  end
end
